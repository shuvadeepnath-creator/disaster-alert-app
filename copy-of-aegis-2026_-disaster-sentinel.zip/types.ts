
export enum HazardType {
  EARTHQUAKE = 'Earthquake',
  FLOOD = 'Flood',
  CYCLONE = 'Cyclone',
  WILDFIRE = 'Wildfire',
  TSUNAMI = 'Tsunami'
}

export enum ThreatLevel {
  LOW = 'Information',
  MEDIUM = 'Advisory',
  HIGH = 'Watch',
  CRITICAL = 'Take Action'
}

export enum ResourceType {
  SHELTER = 'Emergency Shelter',
  HOSPITAL = 'Medical Center',
  SUPPLY_POINT = 'Supply Distribution',
  EVACUATION_HUB = 'Evacuation Hub'
}

export interface FamilyContact {
  id: string;
  name: string;
  relation: string;
  contactInfo: string;
  status: 'Safe' | 'Unknown' | 'Notified';
}

export interface Resource {
  id: string;
  name: string;
  type: ResourceType;
  location: [number, number];
  address: string;
  status: 'Open' | 'Full' | 'Closing' | 'Limited';
  distance?: number;
  contact?: string;
  capacity?: string;
}

export interface DisasterEvent {
  id: string;
  type: HazardType;
  title: string;
  severity: ThreatLevel;
  location: [number, number]; // [lat, lng]
  timestamp: number;
  magnitude?: string;
  description: string;
  source: string;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface AppState {
  events: DisasterEvent[];
  resources: Resource[];
  family: FamilyContact[];
  selectedEvent: DisasterEvent | null;
  selectedResource: Resource | null;
  userLocation: [number, number] | null;
  isSOSActive: boolean;
  threatLevel: ThreatLevel;
  activeTab: 'dashboard' | 'map' | 'resources' | 'family' | 'guardian';
}
