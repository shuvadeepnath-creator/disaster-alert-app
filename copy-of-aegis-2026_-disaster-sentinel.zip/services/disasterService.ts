
import { DisasterEvent, HazardType, ThreatLevel, Resource, ResourceType } from '../types';

const USGS_URL = 'https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson';

/**
 * High-quality mock data used as fallback when network requests fail or for 2026 simulation.
 */
const getFallbackDisasters = (): DisasterEvent[] => [
  {
    id: 'sim-flood-001',
    type: HazardType.FLOOD,
    title: 'Severe Flash Flooding - Jakarta Metropolitan',
    severity: ThreatLevel.HIGH,
    location: [-6.2088, 106.8456],
    timestamp: Date.now() - 1000 * 60 * 30,
    description: 'Heavy seasonal monsoon rainfall causing rapid river rises. Simulation mode active.',
    source: 'Aegis Simulated / CAP'
  },
  {
    id: 'sim-cyclone-001',
    type: HazardType.CYCLONE,
    title: 'Cyclone Zandile - Category 4',
    severity: ThreatLevel.CRITICAL,
    location: [-18.7669, 46.8691],
    timestamp: Date.now() - 1000 * 60 * 60 * 2,
    description: 'Intense tropical cyclone approaching eastern coastline. High storm surge expected.',
    source: 'Meteo France / Simulation'
  },
  {
    id: 'sim-quake-001',
    type: HazardType.EARTHQUAKE,
    title: 'M 7.2 - 15km SW of Port-Vila, Vanuatu',
    severity: ThreatLevel.CRITICAL,
    location: [-17.85, 168.21],
    timestamp: Date.now() - 1000 * 60 * 45,
    magnitude: '7.2',
    description: 'Major seismic event detected. Tsunami watch issued for surrounding islands.',
    source: 'Historical Archive / Simulation'
  },
  {
    id: 'sim-wildfire-001',
    type: HazardType.WILDFIRE,
    title: 'Blue Ridge Wildfire - Rapid Expansion',
    severity: ThreatLevel.HIGH,
    location: [34.0522, -118.2437],
    timestamp: Date.now() - 1000 * 60 * 120,
    description: 'Extreme fire behavior reported. Evacuation orders in effect for Sector 7.',
    source: 'CalFire / Simulation'
  }
];

export const fetchDisasters = async (): Promise<DisasterEvent[]> => {
  try {
    // Attempt to fetch from USGS with a timeout to prevent hanging
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);

    const response = await fetch(USGS_URL, { signal: controller.signal });
    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();

    const earthquakes: DisasterEvent[] = (data.features || []).map((f: any) => {
      const mag = f.properties.mag;
      let severity = ThreatLevel.LOW;
      if (mag >= 7.0) severity = ThreatLevel.CRITICAL;
      else if (mag >= 6.0) severity = ThreatLevel.HIGH;
      else if (mag >= 4.5) severity = ThreatLevel.MEDIUM;

      return {
        id: f.id,
        type: HazardType.EARTHQUAKE,
        title: f.properties.title,
        severity,
        location: [f.geometry.coordinates[1], f.geometry.coordinates[0]],
        timestamp: f.properties.time,
        magnitude: mag?.toFixed(1) || 'N/A',
        description: f.properties.place,
        source: 'USGS (Live)'
      };
    });

    // Merge live data with simulated multi-hazard data for a full 2026 experience
    const liveQuakes = earthquakes.slice(0, 10);
    const simulated = getFallbackDisasters();
    
    // Filter out simulated quakes if we have live ones
    return [...liveQuakes, ...simulated.filter(s => s.type !== HazardType.EARTHQUAKE || liveQuakes.length === 0)];

  } catch (error) {
    console.warn('Live disaster feed unavailable, switching to Aegis Simulation Mode:', error);
    // If live fetch fails (CORS, offline, timeout), return the robust simulated dataset
    return getFallbackDisasters();
  }
};

export const fetchResources = async (userLocation: [number, number] | null): Promise<Resource[]> => {
  // Use user location to generate "nearby" mock resources
  const baseLat = userLocation ? userLocation[0] : 34.0522;
  const baseLng = userLocation ? userLocation[1] : -118.2437;

  return [
    {
      id: 'res-1',
      name: 'St. Jude Emergency Medical Center',
      type: ResourceType.HOSPITAL,
      location: [baseLat + 0.005, baseLng - 0.003],
      address: '452 Rescue Way, Central District',
      status: 'Open',
      distance: 1.2,
      contact: '+1-800-EMERGENCY',
      capacity: '85% Full'
    },
    {
      id: 'res-2',
      name: 'City Arena Shelter Alpha',
      type: ResourceType.SHELTER,
      location: [baseLat - 0.004, baseLng + 0.008],
      address: '900 Sports Blvd, North Sector',
      status: 'Limited',
      distance: 2.4,
      capacity: '98% Full'
    },
    {
      id: 'res-3',
      name: 'Westside Supply Distribution Hub',
      type: ResourceType.SUPPLY_POINT,
      location: [baseLat + 0.012, baseLng + 0.005],
      address: 'Industrial Park Zone 4',
      status: 'Open',
      distance: 3.8,
      capacity: 'Water/Food/Power available'
    },
    {
      id: 'res-4',
      name: 'Coastal Evacuation Point 12',
      type: ResourceType.EVACUATION_HUB,
      location: [baseLat - 0.015, baseLng - 0.012],
      address: 'Main Highway Exit 44',
      status: 'Open',
      distance: 5.1,
      capacity: 'Transport arriving every 15m'
    }
  ];
};
