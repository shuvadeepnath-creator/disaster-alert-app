
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { ChatMessage } from "../types";

// GATEWAY: Change this instance to connect to open-source or local providers in the future
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Standard text-based safety instructions
 */
export const getSafetyInstructions = async (disasterType: string, history: ChatMessage[]) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: history.map(msg => ({ 
        parts: [{ text: msg.content }] 
      })).concat({
        parts: [{ text: `Current Emergency Context: ${disasterType}. Provide rapid, life-saving advice.` }]
      }),
      config: {
        systemInstruction: "You are Aegis-AI. Formatted for high-stress. Concise bullet points. Prioritize physical safety. If a user says they are trapped, focus on air conservation, noise-making protocols (tap 3 times), and maintaining calm. Mention UWB transponder usage.",
        temperature: 0.2
      }
    });

    return response.text;
  } catch (error) {
    console.error('AI Gateway Error:', error);
    return "Connection degraded. Reverting to local resilience protocols. Follow emergency signs.";
  }
};

/**
 * WORLD MODEL HOOK: Analyze physical surroundings via image
 */
export const analyzePhysicalEnvironment = async (base64Image: string, prompt: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: base64Image
            }
          },
          { text: `SITUATION ANALYSIS: Use your world-model reasoning to analyze this image for danger. ${prompt}` }
        ]
      },
      config: {
        systemInstruction: "Analyze images for structural integrity, flood levels, or fire paths. If looking at rubble, identify voids or potential hazards. Be extremely direct.",
        temperature: 0.1
      }
    });

    return response.text;
  } catch (error) {
    console.error('Vision analysis failed:', error);
    return "Visual analysis currently offline. Use manual assessment.";
  }
};
