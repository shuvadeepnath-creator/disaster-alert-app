
import React, { useState, useEffect, useCallback } from 'react';
import { DisasterEvent, ThreatLevel, HazardType, Resource, FamilyContact } from './types';
import { fetchDisasters, fetchResources } from './services/disasterService';
import Dashboard from './components/Dashboard';
import MapContainer from './components/MapContainer';
import AppVaultWidget from './components/AppVaultWidget';
import AIChat from './components/AIChat';
import NotificationOverlay from './components/NotificationOverlay';
import SOSMode from './components/SOSMode';
import ResourceFinder from './components/ResourceFinder';
import FamilyCircles from './components/FamilyCircles';
import GuardianMode from './components/GuardianMode';
import NeuralRegistry from './components/NeuralRegistry';
import { ShieldAlert, LayoutDashboard, MessageCircle, Map as MapIcon, WifiOff, HeartPulse, Users, ShieldPlus, Cpu, Database } from 'lucide-react';

const App: React.FC = () => {
  const [events, setEvents] = useState<DisasterEvent[]>([]);
  const [resources, setResources] = useState<Resource[]>([]);
  const [family, setFamily] = useState<FamilyContact[]>(() => {
    const saved = localStorage.getItem('aegis_family_circles');
    return saved ? JSON.parse(saved) : [
      { id: '1', name: 'Sarah Miller', relation: 'Spouse', contactInfo: '+1-555-0102', status: 'Unknown' },
      { id: '2', name: 'John Miller Sr.', relation: 'Father', contactInfo: '+1-555-0199', status: 'Unknown' }
    ];
  });
  
  const [selectedEvent, setSelectedEvent] = useState<DisasterEvent | null>(null);
  const [selectedResource, setSelectedResource] = useState<Resource | null>(null);
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);
  const [isSOSActive, setIsSOSActive] = useState(false);
  const [isAIChatOpen, setIsAIChatOpen] = useState(false);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [isSimulationMode, setIsSimulationMode] = useState(false);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'map' | 'resources' | 'family' | 'guardian' | 'registry'>('dashboard');

  useEffect(() => {
    localStorage.setItem('aegis_family_circles', JSON.stringify(family));
  }, [family]);

  useEffect(() => {
    const updateEvents = async () => {
      const data = await fetchDisasters();
      setEvents(data);
      // If all sources are "Simulation", we're in simulation mode
      const allSimulated = data.every(e => e.source.includes('Simulation') || e.source.includes('Simulated'));
      setIsSimulationMode(allSimulated);
    };

    updateEvents();
    const interval = setInterval(updateEvents, 60000);

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
            const loc: [number, number] = [pos.coords.latitude, pos.coords.longitude];
            setUserLocation(loc);
            fetchResources(loc).then(setResources);
        },
        (err) => {
          console.warn('Location blocked, using default', err);
          fetchResources(null).then(setResources);
        }
      );
    }

    const handleOffline = () => setIsOffline(true);
    const handleOnline = () => setIsOffline(false);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('online', handleOnline);

    return () => {
      clearInterval(interval);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('online', handleOnline);
    };
  }, []);

  const handleSelectEvent = useCallback((event: DisasterEvent) => {
    setSelectedEvent(event);
    setSelectedResource(null);
    setActiveTab('map');
  }, []);

  const handleSelectResource = useCallback((resource: Resource) => {
    setSelectedResource(resource);
    setSelectedEvent(null);
    setActiveTab('map');
  }, []);

  const triggerSOS = () => setIsSOSActive(true);

  const currentThreatLevel = events.reduce((acc, ev) => {
    const levels = [ThreatLevel.LOW, ThreatLevel.MEDIUM, ThreatLevel.HIGH, ThreatLevel.CRITICAL];
    if (levels.indexOf(ev.severity) > levels.indexOf(acc)) return ev.severity;
    return acc;
  }, ThreatLevel.LOW);

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-black text-white relative">
      <nav className="w-16 md:w-20 border-r border-white/10 flex flex-col items-center py-8 space-y-8 glass-panel z-50">
        <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center shadow-lg shadow-red-900/40">
          <ShieldAlert size={24} />
        </div>
        <button 
          onClick={() => setActiveTab('dashboard')}
          className={`p-3 rounded-2xl transition-all ${activeTab === 'dashboard' ? 'bg-white/10 text-red-500' : 'text-gray-500 hover:text-white'}`}
          title="Dashboard"
        >
          <LayoutDashboard size={24} />
        </button>
        <button 
          onClick={() => setActiveTab('map')}
          className={`p-3 rounded-2xl transition-all ${activeTab === 'map' ? 'bg-white/10 text-red-500' : 'text-gray-500 hover:text-white'}`}
          title="Map View"
        >
          <MapIcon size={24} />
        </button>
        <button 
          onClick={() => setActiveTab('resources')}
          className={`p-3 rounded-2xl transition-all ${activeTab === 'resources' ? 'bg-white/10 text-red-500' : 'text-gray-500 hover:text-white'}`}
          title="Resources"
        >
          <HeartPulse size={24} />
        </button>
        <button 
          onClick={() => setActiveTab('family')}
          className={`p-3 rounded-2xl transition-all ${activeTab === 'family' ? 'bg-white/10 text-red-500' : 'text-gray-500 hover:text-white'}`}
          title="Family Circles"
        >
          <Users size={24} />
        </button>
        <button 
          onClick={() => setActiveTab('guardian')}
          className={`p-3 rounded-2xl transition-all ${activeTab === 'guardian' ? 'bg-white/10 text-red-500' : 'text-gray-500 hover:text-white'}`}
          title="Guardian Mode"
        >
          <ShieldPlus size={24} />
        </button>
        <button 
          onClick={() => setActiveTab('registry')}
          className={`p-3 rounded-2xl transition-all ${activeTab === 'registry' ? 'bg-white/10 text-blue-500' : 'text-gray-500 hover:text-white'}`}
          title="Neural Registry"
        >
          <Cpu size={24} />
        </button>
        <div className="flex-1" />
        <button 
          onClick={() => setIsAIChatOpen(true)}
          className="p-3 rounded-full bg-blue-600 hover:bg-blue-500 transition-colors shadow-lg shadow-blue-900/40"
        >
          <MessageCircle size={24} />
        </button>
      </nav>

      <main className="flex-1 flex flex-col relative">
        <header className="h-16 px-6 flex items-center justify-between glass-panel border-b border-white/10 z-40">
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold tracking-tight">AEGIS <span className="text-red-600">2026</span></h1>
            <div className="flex gap-2">
              {isOffline && (
                <span className="flex items-center gap-1 text-[10px] px-2 py-0.5 bg-yellow-900/30 text-yellow-500 rounded-full border border-yellow-800 font-bold uppercase">
                  <WifiOff size={10} /> Offline
                </span>
              )}
              {isSimulationMode && (
                <span className="flex items-center gap-1 text-[10px] px-2 py-0.5 bg-blue-900/30 text-blue-400 rounded-full border border-blue-800 font-bold uppercase">
                  <Database size={10} /> Simulation Mode
                </span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-4">
            <AppVaultWidget threatLevel={currentThreatLevel} onSOS={triggerSOS} />
          </div>
        </header>

        <div className="flex-1 relative overflow-hidden">
          {activeTab === 'dashboard' && <Dashboard events={events} onSelect={handleSelectEvent} userLocation={userLocation} />}
          {activeTab === 'map' && <MapContainer events={events} resources={resources} selectedEvent={selectedEvent} selectedResource={selectedResource} userLocation={userLocation} />}
          {activeTab === 'resources' && <ResourceFinder resources={resources} onSelect={handleSelectResource} userLocation={userLocation} />}
          {activeTab === 'family' && <FamilyCircles contacts={family} setContacts={setFamily} userLocation={userLocation} />}
          {activeTab === 'guardian' && <GuardianMode />}
          {activeTab === 'registry' && <NeuralRegistry />}
        </div>
      </main>

      {isAIChatOpen && <AIChat onClose={() => setIsAIChatOpen(false)} initialContext={selectedEvent?.type || "General safety"} />}
      {isSOSActive && <SOSMode contacts={family} onCancel={() => setIsSOSActive(false)} />}
      <NotificationOverlay events={events} />
    </div>
  );
};

export default App;
