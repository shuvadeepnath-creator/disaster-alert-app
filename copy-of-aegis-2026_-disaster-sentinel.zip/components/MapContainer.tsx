
import React, { useEffect } from 'react';
import { MapContainer as LeafletMap, TileLayer, Marker, Popup, Circle, useMap } from 'react-leaflet';
import L from 'leaflet';
import { DisasterEvent, ThreatLevel, Resource, ResourceType } from '../types';

interface MapProps {
  events: DisasterEvent[];
  resources: Resource[];
  selectedEvent: DisasterEvent | null;
  selectedResource: Resource | null;
  userLocation: [number, number] | null;
}

const DefaultIcon = L.icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});

const RedIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const GreenIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const RecenterMap: React.FC<{ coords: [number, number] | null }> = ({ coords }) => {
  const map = useMap();
  useEffect(() => {
    if (coords) {
      map.setView(coords, 14, { animate: true });
    }
  }, [coords, map]);
  return null;
};

const MapContainer: React.FC<MapProps> = ({ events, resources, selectedEvent, selectedResource, userLocation }) => {
  const center: [number, number] = userLocation || [20, 0];

  return (
    <div className="w-full h-full relative">
      <LeafletMap 
        center={center} 
        zoom={selectedResource ? 14 : 2} 
        className="w-full h-full"
        scrollWheelZoom={true}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        />
        
        <RecenterMap coords={selectedEvent?.location || selectedResource?.location || userLocation} />

        {userLocation && (
          <Circle 
            center={userLocation} 
            radius={1000} 
            pathOptions={{ fillColor: 'blue', color: 'blue', opacity: 0.1, fillOpacity: 0.2 }} 
          />
        )}

        {/* Disaster Events */}
        {events.map((event) => (
          <Marker 
            key={event.id} 
            position={event.location} 
            icon={event.severity === ThreatLevel.CRITICAL ? RedIcon : DefaultIcon}
          >
            <Popup className="custom-popup">
              <div className="text-black p-2 min-w-[200px]">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-red-600">
                    {event.type} - {event.severity}
                  </span>
                  <span className="text-[10px] text-gray-500">{new Date(event.timestamp).toLocaleTimeString()}</span>
                </div>
                <h3 className="font-bold text-sm mb-1">{event.title}</h3>
                <p className="text-xs text-gray-600 mb-3">{event.description}</p>
                <div className="flex gap-2">
                   <button className="flex-1 bg-red-600 text-white text-[10px] py-2 rounded-lg font-bold uppercase">Emergency Guide</button>
                   <button className="flex-1 bg-gray-200 text-gray-800 text-[10px] py-2 rounded-lg font-bold uppercase">Local Aid</button>
                </div>
              </div>
            </Popup>
          </Marker>
        ))}

        {/* Resources */}
        {resources.map((res) => (
          <Marker 
            key={res.id} 
            position={res.location} 
            icon={GreenIcon}
          >
            <Popup>
              <div className="text-black p-2 min-w-[180px]">
                <span className="text-[9px] font-bold text-emerald-600 uppercase tracking-widest">{res.type}</span>
                <h3 className="font-bold text-sm mb-1">{res.name}</h3>
                <p className="text-[10px] text-gray-500 mb-2">{res.address}</p>
                <div className="flex items-center justify-between mb-3">
                   <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold uppercase ${
                     res.status === 'Open' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                   }`}>{res.status}</span>
                   <span className="text-[10px] font-bold text-gray-400">{res.distance} km</span>
                </div>
                <button className="w-full bg-emerald-600 text-white text-[10px] py-2 rounded-lg font-bold uppercase">Navigate</button>
              </div>
            </Popup>
          </Marker>
        ))}
      </LeafletMap>

      <div className="absolute bottom-6 right-6 glass-panel p-4 rounded-2xl z-[1000] border border-white/10 hidden md:block">
        <h4 className="text-xs font-bold uppercase mb-3 text-gray-400">Map Overlay</h4>
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs">
            <span className="w-3 h-3 rounded-full bg-red-600" /> Active Threat
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="w-3 h-3 rounded-full bg-emerald-600" /> Medical/Shelter
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="w-3 h-3 rounded-full bg-blue-600" /> Your Location
          </div>
        </div>
      </div>
    </div>
  );
};

export default MapContainer;
