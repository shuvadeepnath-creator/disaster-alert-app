
import React, { useState, useEffect } from 'react';
import { Cpu, Globe, ShieldCheck, Zap, Server, Database, RefreshCw, Info } from 'lucide-react';

const NeuralRegistry: React.FC = () => {
  const [activeModel, setActiveModel] = useState<'cloud' | 'local'>('cloud');
  const [latency, setLatency] = useState(124);
  const [syncProgress, setSyncProgress] = useState(92);

  useEffect(() => {
    const interval = setInterval(() => {
      setLatency(activeModel === 'cloud' ? Math.floor(Math.random() * 50) + 100 : Math.floor(Math.random() * 20) + 15);
    }, 3000);
    return () => clearInterval(interval);
  }, [activeModel]);

  return (
    <div className="p-6 h-full flex flex-col space-y-6 bg-[#050505] overflow-y-auto no-scrollbar">
      <div className="space-y-1">
        <h2 className="text-2xl font-black tracking-tight flex items-center gap-3">
          <Cpu className="text-blue-500" size={28} />
          Neural Registry
        </h2>
        <p className="text-gray-500 text-sm">Configure World Models and Open-Source AI Gateways.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Model Selector Card */}
        <div className="glass-panel p-6 rounded-[32px] border border-white/10 space-y-6">
          <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400">Core Logic Provider</h3>
          
          <div className="space-y-3">
            <button 
              onClick={() => setActiveModel('cloud')}
              className={`w-full p-4 rounded-2xl border-2 transition-all flex items-center justify-between group ${
                activeModel === 'cloud' ? 'border-blue-600 bg-blue-600/10' : 'border-white/5 bg-white/5 grayscale opacity-60'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white">
                  <Globe size={20} />
                </div>
                <div className="text-left">
                  <p className="font-bold text-sm">Gemini 3 Flash</p>
                  <p className="text-[10px] text-blue-400 font-bold uppercase tracking-tighter">Ultra-Performance Cloud</p>
                </div>
              </div>
              <div className={`w-5 h-5 rounded-full border-4 ${activeModel === 'cloud' ? 'border-blue-600 bg-white' : 'border-white/20'}`} />
            </button>

            <button 
              onClick={() => setActiveModel('local')}
              className={`w-full p-4 rounded-2xl border-2 transition-all flex items-center justify-between group ${
                activeModel === 'local' ? 'border-emerald-600 bg-emerald-600/10' : 'border-white/5 bg-white/5 grayscale opacity-60'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center text-white">
                  <Database size={20} />
                </div>
                <div className="text-left">
                  <p className="font-bold text-sm">Aegis-Llama 2026</p>
                  <p className="text-[10px] text-emerald-400 font-bold uppercase tracking-tighter">Open-Source Offline Edge AI</p>
                </div>
              </div>
              <div className={`w-5 h-5 rounded-full border-4 ${activeModel === 'local' ? 'border-emerald-600 bg-white' : 'border-white/20'}`} />
            </button>
          </div>

          <div className="p-4 bg-white/5 rounded-2xl flex gap-3">
            <Info className="text-gray-500 shrink-0" size={16} />
            <p className="text-[10px] text-gray-500 leading-relaxed">
              Open-source models run locally on your device hardware (NPU). No data is sent to external servers, and it works without internet access.
            </p>
          </div>
        </div>

        {/* Real-time Diagnostics */}
        <div className="glass-panel p-6 rounded-[32px] border border-white/10 flex flex-col justify-between">
           <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-6">Inference Diagnostics</h3>
           
           <div className="space-y-8">
              <div className="flex items-center justify-between">
                 <div className="flex items-center gap-3">
                    <Zap className="text-yellow-500" size={20} />
                    <span className="text-sm font-semibold">Inference Latency</span>
                 </div>
                 <span className="text-xl font-black text-white">{latency}ms</span>
              </div>

              <div className="flex items-center justify-between">
                 <div className="flex items-center gap-3">
                    <Server className="text-blue-500" size={20} />
                    <span className="text-sm font-semibold">Model Health</span>
                 </div>
                 <span className="text-xs px-2 py-1 bg-emerald-500/20 text-emerald-500 rounded font-bold">STABLE</span>
              </div>

              <div className="space-y-2">
                 <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-gray-500">
                    <span>Edge Weights Sync</span>
                    <span>{syncProgress}%</span>
                 </div>
                 <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-600 transition-all duration-1000" style={{ width: `${syncProgress}%` }} />
                 </div>
              </div>
           </div>

           <button 
             onClick={() => setSyncProgress(0)}
             className="mt-8 w-full py-3 bg-white/5 hover:bg-white/10 rounded-xl flex items-center justify-center gap-2 text-xs font-bold uppercase tracking-widest transition-all"
           >
              <RefreshCw size={14} className={syncProgress < 100 ? 'animate-spin' : ''} /> Force Knowledge Sync
           </button>
        </div>
      </div>

      <section className="space-y-4">
        <h3 className="text-lg font-bold">World Model Transparency Report</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
           {[
             { label: 'Spatial Reasoning', status: 'Active', icon: <ShieldCheck size={16}/> },
             { label: 'Multi-modal Vision', status: 'Active', icon: <ShieldCheck size={16}/> },
             { label: 'Historical Triage', status: 'Offline-Cached', icon: <RefreshCw size={16}/> },
           ].map((item, i) => (
             <div key={i} className="glass-panel p-4 rounded-2xl flex items-center gap-4 border border-white/5">
                <div className="text-emerald-500">{item.icon}</div>
                <div>
                   <p className="text-xs font-bold">{item.label}</p>
                   <p className="text-[9px] text-gray-500 uppercase">{item.status}</p>
                </div>
             </div>
           ))}
        </div>
      </section>
    </div>
  );
};

export default NeuralRegistry;
