
import React, { useEffect, useState } from 'react';
import { DisasterEvent, ThreatLevel } from '../types';
import { AlertTriangle, ShieldAlert, X } from 'lucide-react';

interface Props {
  events: DisasterEvent[];
}

const NotificationOverlay: React.FC<Props> = ({ events }) => {
  const [visibleAlert, setVisibleAlert] = useState<DisasterEvent | null>(null);

  useEffect(() => {
    // Look for new critical events
    const critical = events.find(e => e.severity === ThreatLevel.CRITICAL);
    if (critical) {
      // Logic would check if it's already been shown, but for demo we just show the first one found
      setVisibleAlert(critical);
    }
  }, [events]);

  if (!visibleAlert) return null;

  return (
    <div className="fixed top-0 left-0 w-full h-full pointer-events-none z-[200] flex flex-col items-center pt-8">
      <div className="w-[90%] max-w-[500px] pointer-events-auto glass-panel border-2 border-red-600 bg-red-950/40 rounded-3xl p-6 shadow-[0_0_50px_rgba(220,38,38,0.3)] animate-bounce-short">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-3">
             <div className="p-3 bg-red-600 rounded-2xl">
                <ShieldAlert className="text-white" size={24} />
             </div>
             <div>
                <h2 className="text-xl font-black text-white leading-tight uppercase tracking-tighter">Emergency Alert</h2>
                <p className="text-red-400 text-xs font-bold uppercase tracking-widest">Immediate Action Required</p>
             </div>
          </div>
          <button onClick={() => setVisibleAlert(null)} className="p-2 hover:bg-white/10 rounded-full">
            <X size={20} />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <h3 className="text-lg font-bold text-white mb-1">{visibleAlert.title}</h3>
            <p className="text-sm text-red-100/80 leading-relaxed">{visibleAlert.description}</p>
          </div>
          
          <div className="grid grid-cols-2 gap-3 pt-2">
            <button className="py-3 bg-white text-red-700 font-black rounded-2xl text-sm uppercase tracking-wider shadow-lg">
              Evacuate Now
            </button>
            <button className="py-3 bg-red-700/50 text-white font-bold rounded-2xl text-sm uppercase tracking-wider border border-red-600">
              Show Route
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotificationOverlay;
