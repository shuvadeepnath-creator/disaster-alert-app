
import React, { useState, useRef, useEffect } from 'react';
import { getSafetyInstructions, analyzePhysicalEnvironment } from '../services/geminiService';
import { ChatMessage } from '../types';
import { Send, X, Bot, User, Loader2, Info, Camera, Image as ImageIcon, Sparkles } from 'lucide-react';

interface ChatProps {
  onClose: () => void;
  initialContext: string;
}

const AIChat: React.FC<ChatProps> = ({ onClose, initialContext }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'assistant', content: `Emergency Assistant active. Lens enabled. I am monitoring for ${initialContext}. How can I help?` }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isLensActive, setIsLensActive] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (imageOverride?: string) => {
    if (!input.trim() && !imageOverride) return;
    if (isLoading) return;

    const currentInput = input;
    setInput('');
    setIsLoading(true);

    if (imageOverride) {
      setMessages(prev => [...prev, { role: 'user', content: "[Visual Data Sent for Analysis]" }]);
      const response = await analyzePhysicalEnvironment(imageOverride, currentInput || "Analyze this situation.");
      setMessages(prev => [...prev, { role: 'assistant', content: response || "Analysis complete. Proceed with caution." }]);
    } else {
      setMessages(prev => [...prev, { role: 'user', content: currentInput }]);
      const response = await getSafetyInstructions(initialContext, [...messages, { role: 'user', content: currentInput }]);
      setMessages(prev => [...prev, { role: 'assistant', content: response || "Protocol sync failed." }]);
    }
    
    setIsLoading(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = (reader.result as string).split(',')[1];
        handleSend(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="fixed inset-0 md:inset-auto md:right-8 md:bottom-8 md:w-[450px] md:h-[650px] z-[100] flex flex-col glass-panel md:rounded-3xl border border-white/10 shadow-2xl overflow-hidden bg-[#0a0a0a]">
      {/* Header */}
      <div className="p-4 border-b border-white/10 flex items-center justify-between bg-blue-600/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center relative">
            <Bot size={20} />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-black animate-pulse" />
          </div>
          <div>
            <h3 className="font-bold text-sm">AEGIS Sentinel AI</h3>
            <span className="text-[10px] text-blue-400 font-bold uppercase tracking-wider flex items-center gap-1">
              <Sparkles size={10} /> Neural World Model Active
            </span>
          </div>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors text-gray-400">
          <X size={20} />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar" ref={scrollRef}>
        <div className="bg-blue-900/10 border border-blue-700/30 p-3 rounded-xl flex gap-3 text-[10px] text-blue-400">
          <Info size={14} className="flex-shrink-0" />
          <p>World Model Mode: You can send photos for structural and environmental analysis.</p>
        </div>

        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-8 h-8 rounded-lg flex-shrink-0 flex items-center justify-center ${msg.role === 'user' ? 'bg-gray-700' : 'bg-blue-600 shadow-[0_0_10px_rgba(37,99,235,0.4)]'}`}>
                {msg.role === 'user' ? <User size={16} /> : <Bot size={16} />}
              </div>
              <div className={`p-4 rounded-2xl text-sm leading-relaxed ${
                msg.role === 'user' ? 'bg-white/10 text-white rounded-tr-none' : 'bg-blue-900/20 text-blue-50 border border-blue-800/30 rounded-tl-none'
              }`}>
                {msg.content.split('\n').map((line, j) => (
                  <p key={j} className={line.startsWith('*') || line.startsWith('-') ? 'ml-2 mb-1 border-l border-blue-500/30 pl-3' : 'mb-2'}>
                    {line}
                  </p>
                ))}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-blue-900/20 p-4 rounded-2xl border border-blue-800/30 animate-pulse">
              <Loader2 size={16} className="animate-spin text-blue-400" />
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-4 border-t border-white/10 bg-black/40 space-y-3">
        <div className="flex items-center gap-2">
          <input 
            type="file" 
            accept="image/*" 
            className="hidden" 
            ref={fileInputRef}
            onChange={handleImageUpload}
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-white/5 border border-white/10 text-gray-400 hover:bg-white/10 transition-all text-xs font-bold uppercase tracking-wider"
          >
            <Camera size={16} className="text-blue-500" /> Use Lens
          </button>
          <button className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-white/5 border border-white/10 text-gray-400 hover:bg-white/10 transition-all text-xs font-bold uppercase tracking-wider">
            <ImageIcon size={16} className="text-emerald-500" /> Gallery
          </button>
        </div>

        <div className="flex items-center gap-2 bg-white/5 p-1 rounded-2xl border border-white/10">
          <input 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type your concern..."
            className="flex-1 bg-transparent border-none focus:ring-0 text-sm px-3 h-10 outline-none"
          />
          <button 
            onClick={() => handleSend()}
            disabled={isLoading || !input.trim()}
            className="w-10 h-10 bg-blue-600 hover:bg-blue-500 disabled:opacity-30 transition-colors rounded-xl flex items-center justify-center shadow-lg shadow-blue-900/40"
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default AIChat;
