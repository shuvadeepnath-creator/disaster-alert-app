
import React, { useState, useEffect } from 'react';
import { Phone, X, Shield, Activity, MapPin, Users } from 'lucide-react';
import { FamilyContact } from '../types';

interface SOSProps {
  onCancel: () => void;
  contacts?: FamilyContact[];
}

const SOSMode: React.FC<SOSProps> = ({ onCancel, contacts = [] }) => {
  const [countdown, setCountdown] = useState(5);
  const [isTransmitting, setIsTransmitting] = useState(false);

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setIsTransmitting(true);
    }
  }, [countdown]);

  return (
    <div className="fixed inset-0 z-[300] bg-red-900 flex flex-col items-center justify-center p-8 overflow-hidden">
      <div className="absolute inset-0 bg-red-800 animate-pulse opacity-50" />
      
      {!isTransmitting ? (
        <div className="relative z-10 text-center space-y-8 max-w-md">
          <div className="w-32 h-32 rounded-full border-4 border-white mx-auto flex items-center justify-center text-6xl font-black text-white">
            {countdown}
          </div>
          <div className="space-y-4">
            <h1 className="text-4xl font-black text-white uppercase tracking-tighter">Emergency SOS</h1>
            <p className="text-red-100 text-lg">Contacting local emergency services and broadcasting to {contacts.length} family members.</p>
          </div>
          <button 
            onClick={onCancel}
            className="w-full py-4 bg-white text-red-900 font-bold rounded-2xl text-xl shadow-2xl hover:bg-red-50 transition-colors"
          >
            CANCEL REQUEST
          </button>
        </div>
      ) : (
        <div className="relative z-10 w-full max-w-md space-y-8">
           <div className="flex justify-center">
              <div className="w-24 h-24 rounded-full bg-white flex items-center justify-center animate-ping absolute" />
              <div className="w-24 h-24 rounded-full bg-white flex items-center justify-center relative shadow-2xl">
                <Activity className="text-red-600" size={40} />
              </div>
           </div>

           <div className="glass-panel p-6 rounded-3xl space-y-6 bg-red-950/40 border-white/20 shadow-2xl">
              <h2 className="text-2xl font-black text-white text-center">TRANSMITTING SOS</h2>
              
              <div className="space-y-3">
                 <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-2 text-red-200"><MapPin size={16}/> GPS Location</span>
                    <span className="text-green-400 font-bold">LOCKED</span>
                 </div>
                 <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-2 text-red-200"><Users size={16}/> Circle Alert</span>
                    <span className="text-green-400 font-bold">{contacts.length} NOTIFIED</span>
                 </div>
                 <div className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-2 text-red-200"><Phone size={16}/> Emergency Call</span>
                    <span className="text-yellow-400 font-bold">CONNECTING...</span>
                 </div>
              </div>

              {contacts.length > 0 && (
                <div className="pt-2 border-t border-white/10 space-y-2">
                   <p className="text-[10px] text-red-300 font-bold uppercase tracking-widest">Active Broadcasting:</p>
                   <div className="flex flex-wrap gap-2">
                      {contacts.map(c => (
                        <div key={c.id} className="text-[9px] bg-white/10 px-2 py-1 rounded text-white flex items-center gap-1">
                          <div className="w-1 h-1 bg-green-400 rounded-full animate-pulse" /> {c.name}
                        </div>
                      ))}
                   </div>
                </div>
              )}

              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                 <div className="h-full bg-green-400 w-2/3 animate-[progress_2s_ease-in-out_infinite]" />
              </div>
           </div>

           <button 
            onClick={onCancel}
            className="w-full py-4 border-2 border-white/30 text-white font-bold rounded-2xl text-lg hover:bg-white/10 transition-colors"
          >
            END SOS SESSION
          </button>
        </div>
      )}

      <style>{`
        @keyframes progress {
          0% { width: 0%; }
          100% { width: 100%; }
        }
        .animate-bounce-short {
          animation: bounce 0.5s ease-in-out;
        }
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
      `}</style>
    </div>
  );
};

export default SOSMode;
