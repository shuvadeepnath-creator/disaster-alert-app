
import React, { useState, useEffect } from 'react';
// Fixed: Navigation3d is not a valid export from lucide-react; using Navigation instead.
import { Radio, Activity, Navigation, Mic2, ShieldAlert, Wifi, Zap } from 'lucide-react';

interface Props {
  onExit: () => void;
}

const DeepRescue: React.FC<Props> = ({ onExit }) => {
  const [isTransmitting, setIsTransmitting] = useState(true);
  const [depthEstimate, setDepthEstimate] = useState(0);
  const [orientation, setOrientation] = useState({ x: 0, y: 0, z: 0 });

  // Simulate UWB/Seismic Transmission
  useEffect(() => {
    const interval = setInterval(() => {
      // In a real 2026 Android app, this would trigger the hardware vibrator
      // and the UWB radio pulses.
      console.log("Broadcasting Seismic Pulse...");
    }, 2000);
    
    const handleMotion = (e: DeviceOrientationEvent) => {
      setOrientation({
        x: Math.round(e.beta || 0),
        y: Math.round(e.gamma || 0),
        z: Math.round(e.alpha || 0)
      });
    };

    window.addEventListener('deviceorientation', handleMotion);
    return () => {
      clearInterval(interval);
      window.removeEventListener('deviceorientation', handleMotion);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-[400] bg-black flex flex-col p-6 overflow-hidden">
      {/* Background Pulse Animation */}
      <div className="absolute inset-0 flex items-center justify-center opacity-20">
        <div className="w-[500px] h-[500px] rounded-full border border-blue-500 animate-[ping_3s_linear_infinite]" />
        <div className="w-[300px] h-[300px] rounded-full border border-blue-400 animate-[ping_2s_linear_infinite]" />
      </div>

      <header className="relative z-10 flex justify-between items-center mb-8">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-600 rounded-lg">
            <Radio size={20} className="animate-pulse" />
          </div>
          <h2 className="text-xl font-black uppercase tracking-tighter">Deep Rescue Transponder</h2>
        </div>
        <button onClick={onExit} className="px-4 py-2 bg-white/10 rounded-xl text-xs font-bold uppercase">Exit</button>
      </header>

      <div className="flex-1 relative z-10 flex flex-col gap-6">
        {/* Spatial Orientation (Knowing which way is UP) */}
        <div className="glass-panel p-6 rounded-[32px] border border-blue-500/30 bg-blue-950/10 text-center">
          <p className="text-[10px] font-bold text-blue-400 uppercase tracking-widest mb-4">Spatial Orientation (Gyro)</p>
          <div className="flex justify-center items-center h-32 relative">
            <div 
              className="w-24 h-24 border-2 border-white/20 rounded-xl flex items-center justify-center transition-transform duration-75"
              style={{ transform: `rotateX(${orientation.x}deg) rotateY(${orientation.y}deg)` }}
            >
              <div className="w-1 h-8 bg-blue-500 rounded-full animate-bounce" />
            </div>
            <p className="absolute bottom-0 text-[10px] text-gray-500">Device Tilt: {orientation.x}° / {orientation.y}°</p>
          </div>
          <p className="mt-4 text-sm font-bold">Relative "UP" is identified. Stay oriented.</p>
        </div>

        {/* Transmission Status */}
        <div className="grid grid-cols-2 gap-4">
          <div className="glass-panel p-4 rounded-3xl border border-white/5 bg-white/5">
            <div className="flex items-center gap-2 mb-2">
              <Zap size={14} className="text-yellow-500" />
              <span className="text-[10px] font-bold uppercase">Seismic Pulse</span>
            </div>
            <p className="text-lg font-black text-emerald-500">ACTIVE</p>
            <p className="text-[9px] text-gray-500 leading-tight mt-1">Vibrating at 20Hz for ground sensors.</p>
          </div>
          <div className="glass-panel p-4 rounded-3xl border border-white/5 bg-white/5">
            <div className="flex items-center gap-2 mb-2">
              <Wifi size={14} className="text-blue-500" />
              <span className="text-[10px] font-bold uppercase">UWB Locator</span>
            </div>
            <p className="text-lg font-black text-blue-500">BEACONING</p>
            <p className="text-[9px] text-gray-500 leading-tight mt-1">Centimeter-level precision finding enabled.</p>
          </div>
        </div>

        {/* Action Center */}
        <div className="mt-auto space-y-4">
           <div className="p-4 bg-red-950/20 border border-red-500/30 rounded-2xl flex items-center gap-4">
              <ShieldAlert className="text-red-500 shrink-0" size={24} />
              <div className="text-xs">
                <p className="font-bold text-red-500 uppercase">Save Battery Mode</p>
                <p className="text-gray-400">Screen dimmed to 1%. Transponder uses minimal NPU power.</p>
              </div>
           </div>

           <button className="w-full py-6 bg-blue-600 rounded-[24px] flex flex-col items-center justify-center gap-1 shadow-xl shadow-blue-900/40">
              <Mic2 size={24} />
              <span className="text-sm font-black uppercase tracking-widest">Listen for Rescuers</span>
              <span className="text-[10px] opacity-60">AI will filter out debris noise</span>
           </button>
        </div>
      </div>
    </div>
  );
};

export default DeepRescue;
