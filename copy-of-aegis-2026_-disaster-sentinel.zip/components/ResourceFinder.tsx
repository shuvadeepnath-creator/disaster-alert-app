
import React, { useState } from 'react';
import { Resource, ResourceType } from '../types';
import { Home, HeartPulse, Truck, Navigation, Phone, Search, Filter } from 'lucide-react';

interface Props {
  resources: Resource[];
  onSelect: (resource: Resource) => void;
  userLocation: [number, number] | null;
}

const ResourceIcon = ({ type }: { type: ResourceType }) => {
  switch (type) {
    case ResourceType.SHELTER: return <Home className="text-emerald-500" />;
    case ResourceType.HOSPITAL: return <HeartPulse className="text-red-500" />;
    case ResourceType.SUPPLY_POINT: return <Truck className="text-amber-500" />;
    case ResourceType.EVACUATION_HUB: return <Navigation className="text-blue-500" />;
    default: return <Search className="text-gray-500" />;
  }
};

const ResourceFinder: React.FC<Props> = ({ resources, onSelect, userLocation }) => {
  const [filter, setFilter] = useState<string>('All');
  const [search, setSearch] = useState<string>('');

  const filteredResources = resources.filter(res => {
    const matchesFilter = filter === 'All' || res.type === filter;
    const matchesSearch = res.name.toLowerCase().includes(search.toLowerCase()) || 
                          res.address.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const categories = ['All', ...Object.values(ResourceType)];

  return (
    <div className="p-6 h-full flex flex-col space-y-6 bg-[#050505]">
      <div className="space-y-4">
        <h2 className="text-2xl font-black tracking-tight">Shelter & Resource Finder</h2>
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
            <input 
              type="text" 
              placeholder="Search hospitals, shelters..." 
              className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 pl-12 pr-4 text-sm outline-none focus:border-red-500 transition-colors"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
            {categories.map(cat => (
              <button 
                key={cat}
                onClick={() => setFilter(cat)}
                className={`flex-shrink-0 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all border ${
                  filter === cat ? 'bg-red-600 border-red-500 text-white' : 'bg-white/5 border-white/10 text-gray-400'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-4 pr-2">
        {filteredResources.length > 0 ? (
          filteredResources.map(res => (
            <div 
              key={res.id}
              onClick={() => onSelect(res)}
              className="glass-panel p-5 rounded-3xl flex flex-col md:flex-row gap-6 cursor-pointer hover:bg-white/5 transition-all group"
            >
              <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center shrink-0 group-hover:border-red-500/50">
                <ResourceIcon type={res.type} />
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="text-lg font-bold group-hover:text-red-500 transition-colors">{res.name}</h3>
                    <p className="text-xs text-gray-500 font-medium uppercase tracking-wider">{res.type}</p>
                  </div>
                  <span className={`text-[10px] font-black px-3 py-1 rounded-full uppercase ${
                    res.status === 'Open' ? 'bg-emerald-500/10 text-emerald-500' : 
                    res.status === 'Limited' ? 'bg-amber-500/10 text-amber-500' : 'bg-red-500/10 text-red-500'
                  }`}>
                    {res.status}
                  </span>
                </div>
                <div className="flex flex-wrap gap-x-6 gap-y-2 mt-4 text-[11px] text-gray-400">
                  <span className="flex items-center gap-2"><Navigation size={14} /> {res.address}</span>
                  <span className="flex items-center gap-2"><Search size={14} /> {res.distance} km away</span>
                  {res.capacity && <span className="flex items-center gap-2"><Home size={14} /> {res.capacity}</span>}
                </div>
              </div>
              <div className="flex md:flex-col justify-end gap-2">
                {res.contact && (
                  <button className="flex-1 p-3 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 transition-colors">
                    <Phone size={18} className="mx-auto" />
                  </button>
                )}
                <button className="flex-1 md:flex-none px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs uppercase tracking-widest transition-colors shadow-lg shadow-red-900/20">
                  Route
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="h-64 flex flex-col items-center justify-center text-gray-500 space-y-4">
            <Search size={48} className="opacity-20" />
            <p>No resources found matching your search.</p>
          </div>
        )}
      </div>

      {!userLocation && (
        <div className="bg-red-950/20 border border-red-500/30 p-4 rounded-2xl flex items-center gap-4 text-xs text-red-500">
          <Navigation size={20} className="shrink-0" />
          <p>Location access is restricted. Distances and nearby results may be inaccurate. Please enable GPS for real-time routing.</p>
        </div>
      )}
    </div>
  );
};

export default ResourceFinder;
