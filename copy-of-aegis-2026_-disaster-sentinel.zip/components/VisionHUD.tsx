
import React, { useState, useEffect } from 'react';
import { Eye, Target, Zap, ShieldCheck, Maximize, ScanSearch, Layers } from 'lucide-react';

interface Props {
  onClose: () => void;
}

const VisionHUD: React.FC<Props> = ({ onClose }) => {
  const [scanProgress, setScanProgress] = useState(0);
  const [detectedVoids, setDetectedVoids] = useState<{id: number, x: number, y: number}[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      setScanProgress(p => (p < 100 ? p + 1 : 0));
      if (Math.random() > 0.9) {
        setDetectedVoids(prev => [
          ...prev.slice(-4),
          { id: Date.now(), x: Math.random() * 80 + 10, y: Math.random() * 60 + 20 }
        ]);
      }
    }, 100);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 z-[500] bg-blue-950/20 backdrop-blur-sm flex flex-col items-center justify-center p-4 overflow-hidden">
      {/* AR Overlay Grid */}
      <div className="absolute inset-0 pointer-events-none border-[40px] border-blue-500/10">
        <div className="w-full h-full border border-blue-500/20 grid grid-cols-6 grid-rows-6 opacity-30">
          {Array.from({length: 36}).map((_, i) => (
            <div key={i} className="border border-blue-500/10 flex items-center justify-center">
              <div className="w-1 h-1 bg-blue-500/20 rounded-full" />
            </div>
          ))}
        </div>
      </div>

      {/* Target Reticle */}
      <div className="relative w-64 h-64 flex items-center justify-center">
         <div className="absolute inset-0 border-2 border-blue-500/40 rounded-full animate-spin-slow" />
         <div className="absolute inset-4 border border-blue-400/20 rounded-full animate-reverse-spin" />
         <Target className="text-blue-500 w-12 h-12 animate-pulse" />
         
         {/* Detected Voids / Life Signs */}
         {detectedVoids.map(voidItem => (
           <div 
             key={voidItem.id} 
             className="absolute w-4 h-4 bg-emerald-500/40 border border-emerald-400 rounded-sm animate-ping"
             style={{ left: `${voidItem.x}%`, top: `${voidItem.y}%` }}
           />
         ))}
      </div>

      {/* HUD Data Panels */}
      <div className="absolute top-12 left-12 space-y-4">
        <div className="flex items-center gap-3 bg-blue-600/20 border border-blue-500/40 p-3 rounded-xl">
          <Eye size={20} className="text-blue-400" />
          <div>
            <p className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">Vision HUD v4.0</p>
            <p className="text-sm font-black text-white">RESCUER OVERLAY</p>
          </div>
        </div>
      </div>

      <div className="absolute bottom-12 left-12 right-12 flex justify-between items-end">
         <div className="glass-panel p-6 rounded-[32px] border border-blue-500/30 bg-blue-950/40 max-w-xs">
            <div className="flex items-center gap-2 mb-4">
              <ScanSearch className="text-blue-400" size={16} />
              <span className="text-[10px] font-bold uppercase tracking-widest text-blue-400">Structural Scan</span>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between text-[10px] text-gray-400">
                <span>UWB PENETRATION</span>
                <span>8.4m</span>
              </div>
              <div className="h-1.5 bg-blue-900/50 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500" style={{ width: `${scanProgress}%` }} />
              </div>
              <p className="text-xs text-blue-100/80 leading-relaxed font-medium">
                Rescuers can see your digital 'ghost' through 8 meters of debris via UWB smart-glass bridge.
              </p>
            </div>
         </div>

         <button 
           onClick={onClose}
           className="px-8 py-4 bg-white text-blue-950 font-black rounded-2xl uppercase tracking-widest hover:bg-blue-50 transition-all shadow-2xl"
         >
           Exit HUD
         </button>
      </div>

      <style>{`
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes reverse-spin {
          from { transform: rotate(360deg); }
          to { transform: rotate(0deg); }
        }
        .animate-spin-slow { animation: spin-slow 10s linear infinite; }
        .animate-reverse-spin { animation: reverse-spin 6s linear infinite; }
      `}</style>
    </div>
  );
};

export default VisionHUD;
