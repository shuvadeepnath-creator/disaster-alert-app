
import React, { useState, useEffect } from 'react';
import { ShieldPlus, Zap, Volume2, Battery, Lightbulb, AlertOctagon, HelpCircle, Radio, Eye, Cpu } from 'lucide-react';
import DeepRescue from './DeepRescue';
import VisionHUD from './VisionHUD';
import AutonomousAgent from './AutonomousAgent';

const GuardianMode: React.FC = () => {
  const [isBeaconActive, setIsBeaconActive] = useState(false);
  const [isSoundActive, setIsSoundActive] = useState(false);
  const [isStrobe, setIsStrobe] = useState(false);
  const [showDeepRescue, setShowDeepRescue] = useState(false);
  const [showVisionHUD, setShowVisionHUD] = useState(false);
  const [showAutoAgent, setShowAutoAgent] = useState(false);

  // Strobe effect simulation
  useEffect(() => {
    let interval: any;
    if (isBeaconActive) {
      interval = setInterval(() => {
        setIsStrobe(prev => !prev);
      }, 300);
    } else {
      setIsStrobe(false);
    }
    return () => clearInterval(interval);
  }, [isBeaconActive]);

  const toggleSound = () => {
    setIsSoundActive(!isSoundActive);
    if (!isSoundActive) {
      console.log("Playing emergency whistle...");
    }
  };

  if (showDeepRescue) return <DeepRescue onExit={() => setShowDeepRescue(false)} />;
  if (showVisionHUD) return <VisionHUD onClose={() => setShowVisionHUD(false)} />;
  if (showAutoAgent) return <AutonomousAgent onDeactivate={() => setShowAutoAgent(false)} />;

  return (
    <div className={`p-6 h-full flex flex-col space-y-6 transition-colors duration-300 ${isStrobe ? 'bg-white text-black' : 'bg-black text-white'} overflow-y-auto no-scrollbar`}>
      <div className="flex items-center justify-between">
         <div className="space-y-1">
            <h2 className="text-2xl font-black tracking-tight flex items-center gap-3">
               <ShieldPlus className={isStrobe ? 'text-red-600' : 'text-red-500'} size={28} />
               Guardian Mode
            </h2>
            <p className={`text-xs ${isStrobe ? 'text-gray-600' : 'text-gray-500'}`}>Extreme survival signals & search-and-rescue assistance.</p>
         </div>
         <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-[10px] font-bold border ${isStrobe ? 'border-gray-200' : 'border-white/10 bg-white/5'}`}>
            <Battery size={14} className="text-emerald-500" /> BATTERY OPTIMIZED
         </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Futurist: Autonomous Agent */}
        <button 
          onClick={() => setShowAutoAgent(true)}
          className="glass-panel p-6 rounded-[32px] border-2 border-emerald-600/50 bg-emerald-600/10 flex items-center gap-4 group transition-all"
        >
          <div className="w-12 h-12 rounded-2xl bg-emerald-600 flex items-center justify-center text-white">
            <Cpu size={24} />
          </div>
          <div className="text-left">
            <h3 className="text-sm font-black uppercase">Autonomous Protocol</h3>
            <p className="text-[10px] text-emerald-400 font-bold uppercase">AI Coordination Mode</p>
          </div>
        </button>

        {/* Futurist: Vision HUD */}
        <button 
          onClick={() => setShowVisionHUD(true)}
          className="glass-panel p-6 rounded-[32px] border-2 border-blue-600/50 bg-blue-600/10 flex items-center gap-4 group transition-all"
        >
          <div className="w-12 h-12 rounded-2xl bg-blue-600 flex items-center justify-center text-white">
            <Eye size={24} />
          </div>
          <div className="text-left">
            <h3 className="text-sm font-black uppercase">Vision HUD Overlay</h3>
            <p className="text-[10px] text-blue-400 font-bold uppercase">Rescuer AR Bridge</p>
          </div>
        </button>

        {/* Deep Rescue Specialized Tool */}
        <button 
          onClick={() => setShowDeepRescue(true)}
          className="col-span-full glass-panel p-6 rounded-[32px] border-2 border-red-600/30 bg-red-600/5 flex items-center justify-between group hover:bg-red-600/10 transition-all"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-red-600 flex items-center justify-center text-white">
              <Radio size={24} className="group-hover:scale-110 transition-transform" />
            </div>
            <div className="text-left">
              <h3 className="text-sm font-black uppercase">Deep Rescue Tool</h3>
              <p className="text-[10px] text-red-500 font-bold uppercase tracking-tighter">Beaconing & Seismic Signaling</p>
            </div>
          </div>
          <Zap className="text-red-500 animate-pulse" />
        </button>

        {/* Signal Panel */}
        <div className={`glass-panel p-6 rounded-[32px] flex flex-col items-center justify-center space-y-4 border-2 transition-all ${
           isBeaconActive ? 'border-red-600 bg-red-950/20' : 'border-white/10'
        }`}>
           <button 
             onClick={() => setIsBeaconActive(!isBeaconActive)}
             className={`w-20 h-20 rounded-full flex items-center justify-center transition-all shadow-2xl ${
               isBeaconActive ? 'bg-red-600 text-white scale-110 shadow-red-600/50' : 'bg-white/5 text-gray-500'
             }`}
           >
              <Lightbulb size={32} className={isBeaconActive ? 'animate-pulse' : ''} />
           </button>
           <h3 className="text-xs font-black uppercase tracking-widest text-center">Visual Beacon</h3>
        </div>

        <div className={`glass-panel p-6 rounded-[32px] flex flex-col items-center justify-center space-y-4 border-2 transition-all ${
           isSoundActive ? 'border-blue-600 bg-blue-950/20' : 'border-white/10'
        }`}>
           <button 
             onClick={toggleSound}
             className={`w-20 h-20 rounded-full flex items-center justify-center transition-all shadow-2xl ${
               isSoundActive ? 'bg-blue-600 text-white scale-110 shadow-blue-600/50' : 'bg-white/5 text-gray-500'
             }`}
           >
              <Volume2 size={32} className={isSoundActive ? 'animate-bounce' : ''} />
           </button>
           <h3 className="text-xs font-black uppercase tracking-widest text-center">Rescue Whistle</h3>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pb-8">
        {[
          { icon: <Zap size={18}/>, label: 'Shock Triage' },
          { icon: <AlertOctagon size={18}/>, label: 'Gas Isolation' },
          { icon: <HelpCircle size={18}/>, label: 'S.O.S Guide' },
          { icon: <Battery size={18}/>, label: 'Radio Mode' },
        ].map((item, i) => (
          <button key={i} className={`p-4 rounded-3xl flex flex-col items-center justify-center gap-2 border transition-all ${
            isStrobe ? 'bg-gray-100 border-gray-200 text-black' : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10'
          }`}>
             {item.icon}
             <span className="text-[10px] font-bold uppercase tracking-widest">{item.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default GuardianMode;
