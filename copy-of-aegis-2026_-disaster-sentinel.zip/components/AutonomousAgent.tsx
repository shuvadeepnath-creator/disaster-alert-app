
import React, { useState, useEffect } from 'react';
import { Cpu, ShieldAlert, Mic2, Battery, Radio, MessageSquareOff, ChevronRight } from 'lucide-react';

interface Props {
  onDeactivate: () => void;
}

const AutonomousAgent: React.FC<Props> = ({ onDeactivate }) => {
  const [logs, setLogs] = useState<string[]>([]);

  useEffect(() => {
    const protocolLogs = [
      "Initializing Aegis Autonomous Protocol...",
      "Locking non-essential background processes.",
      "Syncing with Global SAR Registry...",
      "Broadcast ID: SAR-7712-BETA active.",
      "Analyzing heart rate via accelerometer (estimated: 72 bpm).",
      "Optimizing battery: Estimated survival time +12 hours.",
      "Environmental Listening: DEBRIS NOISE DETECTED.",
      "Awaiting Rescuer Signature..."
    ];

    let i = 0;
    const interval = setInterval(() => {
      if (i < protocolLogs.length) {
        setLogs(prev => [...prev, protocolLogs[i]]);
        i++;
      } else {
        clearInterval(interval);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 z-[600] bg-[#050505] flex flex-col p-8">
      <div className="flex items-center justify-between mb-12">
        <div className="flex items-center gap-4">
           <div className="w-12 h-12 rounded-2xl bg-emerald-600 flex items-center justify-center text-white shadow-lg shadow-emerald-900/40">
              <Cpu size={28} className="animate-pulse" />
           </div>
           <div>
              <h2 className="text-xl font-black uppercase tracking-tighter">Autonomous Coordinator</h2>
              <p className="text-[10px] text-emerald-500 font-bold uppercase tracking-widest">Active Level: HIGH AUTHORITY</p>
           </div>
        </div>
        <button onClick={onDeactivate} className="text-xs text-gray-500 hover:text-white uppercase font-bold">Manual Override</button>
      </div>

      <div className="flex-1 flex flex-col gap-6">
        {/* Terminal Logic View */}
        <div className="flex-1 bg-black rounded-[32px] border border-emerald-900/30 p-6 overflow-y-auto no-scrollbar font-mono text-[11px] space-y-2">
          {logs.map((log, i) => (
            <div key={i} className="flex gap-2">
              <span className="text-emerald-900">[{new Date().toLocaleTimeString()}]</span>
              <span className="text-emerald-400 animate-in fade-in slide-in-from-left-2">{log}</span>
            </div>
          ))}
          <div className="w-2 h-4 bg-emerald-500 animate-pulse inline-block" />
        </div>

        {/* Status Dashboard */}
        <div className="grid grid-cols-2 gap-4">
          <div className="glass-panel p-5 rounded-3xl border border-white/5 bg-white/5">
             <div className="flex items-center gap-2 mb-2 text-emerald-500">
               <Mic2 size={16} />
               <span className="text-[10px] font-bold uppercase">Voice Only Mode</span>
             </div>
             <p className="text-xs text-gray-400">Screen disabling in 30s. Listen for my instructions.</p>
          </div>
          <div className="glass-panel p-5 rounded-3xl border border-white/5 bg-white/5">
             <div className="flex items-center gap-2 mb-2 text-blue-500">
               <Battery size={16} />
               <span className="text-[10px] font-bold uppercase">Power State</span>
             </div>
             <p className="text-xs text-gray-400">Core clock restricted. Transceiver at 100%.</p>
          </div>
        </div>

        <div className="p-6 bg-emerald-950/20 border border-emerald-500/30 rounded-[32px] flex items-center gap-6">
           <Radio className="text-emerald-500 animate-ping" size={32} />
           <div>
              <p className="text-sm font-bold text-white uppercase">Coordination Active</p>
              <p className="text-xs text-gray-500 leading-tight">I have notified the nearest search unit. Do not move. Conserve oxygen. I will alert you when they are within 10 meters.</p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default AutonomousAgent;
