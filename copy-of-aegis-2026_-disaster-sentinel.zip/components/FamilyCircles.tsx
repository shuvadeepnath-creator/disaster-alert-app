
import React, { useState } from 'react';
import { FamilyContact } from '../types';
import { Users, Plus, Trash2, CheckCircle, ShieldCheck, MapPin, Send, Info } from 'lucide-react';

interface Props {
  contacts: FamilyContact[];
  setContacts: React.Dispatch<React.SetStateAction<FamilyContact[]>>;
  userLocation: [number, number] | null;
}

const FamilyCircles: React.FC<Props> = ({ contacts, setContacts, userLocation }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newContact, setNewContact] = useState({ name: '', relation: '', info: '' });
  const [lastCheckIn, setLastCheckIn] = useState<string | null>(null);
  const [broadcastStatus, setBroadcastStatus] = useState<boolean>(false);

  const addContact = () => {
    if (!newContact.name || !newContact.info) return;
    const contact: FamilyContact = {
      id: Math.random().toString(36).substr(2, 9),
      name: newContact.name,
      relation: newContact.relation,
      contactInfo: newContact.info,
      status: 'Unknown'
    };
    setContacts([...contacts, contact]);
    setNewContact({ name: '', relation: '', info: '' });
    setIsAdding(false);
  };

  const removeContact = (id: string) => {
    setContacts(contacts.filter(c => c.id !== id));
  };

  const handleSafetyBroadcast = () => {
    setBroadcastStatus(true);
    // Simulate multi-channel broadcast
    setContacts(contacts.map(c => ({ ...c, status: 'Notified' })));
    setLastCheckIn(new Date().toLocaleTimeString());
    
    setTimeout(() => {
      setBroadcastStatus(false);
      setContacts(contacts.map(c => ({ ...c, status: 'Safe' })));
    }, 3000);
  };

  return (
    <div className="p-6 h-full flex flex-col space-y-8 bg-[#050505] overflow-y-auto no-scrollbar">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <h2 className="text-2xl font-black tracking-tight flex items-center gap-3">
            <Users className="text-red-600" size={28} />
            Family Circles
          </h2>
          <p className="text-gray-500 text-sm">Privately manage and notify your emergency circle.</p>
        </div>
        
        <button 
          onClick={handleSafetyBroadcast}
          disabled={broadcastStatus}
          className={`flex items-center gap-3 px-8 py-4 rounded-2xl font-black text-sm uppercase tracking-widest transition-all shadow-xl ${
            broadcastStatus ? 'bg-emerald-600/20 text-emerald-500 cursor-not-allowed' : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-900/20'
          }`}
        >
          {broadcastStatus ? (
            <><Send size={18} className="animate-pulse" /> Broadcasting...</>
          ) : (
            <><ShieldCheck size={18} /> I Am Safe</>
          )}
        </button>
      </div>

      {/* Safety Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="glass-panel p-6 rounded-3xl border-l-4 border-blue-500 bg-blue-950/10">
          <h3 className="text-xs font-bold text-blue-500 uppercase mb-4 tracking-wider">Privacy Notice</h3>
          <div className="flex gap-4">
             <Info className="text-blue-400 shrink-0" size={20} />
             <p className="text-xs text-gray-400 leading-relaxed">
               All contact information is stored <strong>locally on your device</strong>. 
               Aegis 2026 does not upload your personal circles to any central server. 
               Safety broadcasts are sent via direct peer-to-peer or local network protocols.
             </p>
          </div>
        </div>
        
        <div className="glass-panel p-6 rounded-3xl border-l-4 border-emerald-500 bg-emerald-950/10">
          <h3 className="text-xs font-bold text-emerald-500 uppercase mb-4 tracking-wider">Status Overview</h3>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-2xl font-black">{lastCheckIn || 'No Check-in'}</p>
              <p className="text-[10px] text-gray-500 uppercase mt-1">Last Safety Broadcast</p>
            </div>
            {userLocation && (
              <div className="text-right">
                <p className="text-xs font-bold text-emerald-400 flex items-center justify-end gap-1">
                  <MapPin size={12} /> Live Location Shared
                </p>
                <p className="text-[10px] text-gray-500 mt-1 uppercase">With check-in packet</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Circle Management */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-lg">My Circle</h3>
          <button 
            onClick={() => setIsAdding(!isAdding)}
            className="flex items-center gap-2 text-xs font-bold px-4 py-2 bg-white/5 hover:bg-white/10 rounded-xl transition-colors border border-white/10"
          >
            <Plus size={14} /> Add Member
          </button>
        </div>

        {isAdding && (
          <div className="glass-panel p-6 rounded-3xl border border-white/20 animate-in fade-in slide-in-from-top-4 duration-300">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <input 
                placeholder="Full Name" 
                className="bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-red-500"
                value={newContact.name}
                onChange={e => setNewContact({...newContact, name: e.target.value})}
              />
              <input 
                placeholder="Relation (e.g. Spouse)" 
                className="bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-red-500"
                value={newContact.relation}
                onChange={e => setNewContact({...newContact, relation: e.target.value})}
              />
              <input 
                placeholder="Phone or ID" 
                className="bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-red-500"
                value={newContact.info}
                onChange={e => setNewContact({...newContact, info: e.target.value})}
              />
            </div>
            <div className="flex justify-end gap-3">
              <button onClick={() => setIsAdding(false)} className="px-6 py-2 text-sm text-gray-500 hover:text-white transition-colors">Cancel</button>
              <button onClick={addContact} className="px-8 py-2 bg-red-600 text-white font-bold rounded-xl text-sm">Save Contact</button>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {contacts.map(contact => (
            <div key={contact.id} className="glass-panel p-5 rounded-3xl flex items-center justify-between border border-white/5 group hover:border-white/20 transition-all">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border ${
                  contact.status === 'Safe' ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-white/5 border-white/10'
                }`}>
                  <Users size={20} className={contact.status === 'Safe' ? 'text-emerald-500' : 'text-gray-400'} />
                </div>
                <div>
                  <h4 className="font-bold">{contact.name}</h4>
                  <p className="text-[10px] text-gray-500 uppercase tracking-wider">{contact.relation} • {contact.contactInfo}</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right">
                  <span className={`text-[10px] font-black px-3 py-1 rounded-full uppercase ${
                    contact.status === 'Safe' ? 'bg-emerald-500/20 text-emerald-500' : 
                    contact.status === 'Notified' ? 'bg-blue-500/20 text-blue-500' : 'bg-white/10 text-gray-500'
                  }`}>
                    {contact.status}
                  </span>
                </div>
                <button onClick={() => removeContact(contact.id)} className="p-2 text-gray-600 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100">
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
          {contacts.length === 0 && (
             <div className="md:col-span-2 h-40 flex flex-col items-center justify-center text-gray-600 border-2 border-dashed border-white/5 rounded-3xl">
                <p>No contacts added to your circle.</p>
             </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default FamilyCircles;
