
import React from 'react';
import { DisasterEvent, ThreatLevel, HazardType } from '../types';
import { AlertCircle, Clock, MapPin, Wind, Waves, Flame, Zap, HeartPulse, Navigation, CheckCircle2, Siren } from 'lucide-react';

interface DashboardProps {
  events: DisasterEvent[];
  onSelect: (event: DisasterEvent) => void;
  userLocation: [number, number] | null;
}

const HazardIcon = ({ type }: { type: HazardType }) => {
  switch (type) {
    case HazardType.EARTHQUAKE: return <Zap className="text-yellow-500" />;
    case HazardType.CYCLONE: return <Wind className="text-blue-500" />;
    case HazardType.FLOOD: return <Waves className="text-cyan-500" />;
    case HazardType.WILDFIRE: return <Flame className="text-orange-500" />;
    default: return <AlertCircle className="text-red-500" />;
  }
};

const Dashboard: React.FC<DashboardProps> = ({ events, onSelect }) => {
  const criticalAlerts = events.filter(e => e.severity === ThreatLevel.CRITICAL);
  const currentDisaster = criticalAlerts[0]?.type || HazardType.EARTHQUAKE;

  const getChecklist = (type: HazardType) => {
    switch(type) {
        case HazardType.EARTHQUAKE: return ["Drop, Cover, Hold On", "Check Gas/Water Lines", "Put on Sturdy Shoes", "Evacuate if near Cliffs"];
        case HazardType.FLOOD: return ["Move to Higher Ground", "Turn off Electricity", "Bag Essential Docs", "Avoid Walking in Water"];
        default: return ["Secure Emergency Bag", "Check on Neighbors", "Charge Power Banks", "Monitor Local Radio"];
    }
  };

  return (
    <div className="p-6 h-full overflow-y-auto space-y-8 bg-[#050505] no-scrollbar">
      {/* 2026 Emergency HUD */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-panel p-6 rounded-3xl border-l-4 border-red-600 bg-red-950/10">
          <div className="flex justify-between items-start mb-4">
            <h3 className="text-red-500 font-bold uppercase tracking-wider text-xs">Active Critical</h3>
            <AlertCircle className="text-red-600" />
          </div>
          <p className="text-4xl font-extrabold">{criticalAlerts.length}</p>
          <p className="text-gray-500 text-sm mt-1">Life-threat alerts</p>
        </div>
        <div className="glass-panel p-6 rounded-3xl border-l-4 border-emerald-500 bg-emerald-950/10">
          <div className="flex justify-between items-start mb-4">
            <h3 className="text-emerald-500 font-bold uppercase tracking-wider text-xs">Neighborhood</h3>
            <Siren className="text-emerald-500" />
          </div>
          <p className="text-4xl font-extrabold">3</p>
          <p className="text-gray-500 text-sm mt-1">Verified user reports</p>
        </div>
        <div className="glass-panel p-6 rounded-3xl border-l-4 border-blue-500 bg-blue-950/10">
          <div className="flex justify-between items-start mb-4">
            <h3 className="text-blue-500 font-bold uppercase tracking-wider text-xs">Aegis AI</h3>
            <Clock className="text-blue-500" />
          </div>
          <p className="text-xl font-bold">READY</p>
          <p className="text-gray-500 text-sm mt-1">Satellite sync active</p>
        </div>
      </section>

      {/* Immediate Survival Checklist */}
      <section className="glass-panel p-6 rounded-[32px] border border-white/10 bg-gradient-to-br from-white/5 to-transparent">
        <h2 className="text-xl font-black mb-6 flex items-center gap-2">
            <CheckCircle2 size={24} className="text-red-500" />
            First 60 Seconds: {currentDisaster} Protocol
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {getChecklist(currentDisaster as HazardType).map((item, i) => (
                <div key={i} className="flex items-center gap-4 p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-red-500/50 transition-all cursor-pointer group">
                    <div className="w-6 h-6 rounded-full border-2 border-gray-600 group-hover:border-red-500 flex items-center justify-center shrink-0">
                        <div className="w-2 h-2 rounded-full bg-red-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <span className="text-sm font-semibold">{item}</span>
                </div>
            ))}
        </div>
      </section>

      {/* Critical Threats */}
      {criticalAlerts.length > 0 && (
        <section className="space-y-4">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <span className="w-2 h-2 bg-red-600 rounded-full animate-pulse" />
            Immediate Danger Zones
          </h2>
          <div className="grid grid-cols-1 gap-4">
            {criticalAlerts.map(event => (
              <div 
                key={event.id}
                onClick={() => onSelect(event)}
                className="group relative glass-panel p-6 rounded-3xl cursor-pointer hover:bg-white/5 transition-all overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-red-600/5 blur-3xl rounded-full" />
                <div className="flex flex-col md:flex-row md:items-center gap-6 relative z-10">
                  <div className="w-16 h-16 rounded-2xl bg-red-950/30 flex items-center justify-center border border-red-800/30">
                    <HazardIcon type={event.type} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-1">
                      <span className="px-2 py-0.5 bg-red-600 text-[10px] font-bold rounded-md uppercase tracking-widest">CRITICAL</span>
                      <span className="text-xs text-gray-400 flex items-center gap-1">
                        <Clock size={12} /> {new Date(event.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <h3 className="text-lg font-bold group-hover:text-red-500 transition-colors">{event.title}</h3>
                    <p className="text-gray-400 text-sm mt-1 flex items-center gap-1">
                      <MapPin size={14} /> {event.description}
                    </p>
                  </div>
                  <button className="px-6 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl transition-colors">
                    VIEW MAP
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Quick Links Section */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-4">
            <h2 className="text-xl font-bold">Situation Feed</h2>
            <div className="space-y-3">
              {events.filter(e => e.severity !== ThreatLevel.CRITICAL).slice(0, 3).map(event => (
                <div 
                  key={event.id}
                  onClick={() => onSelect(event)}
                  className="glass-panel p-4 rounded-2xl flex gap-4 cursor-pointer hover:bg-white/5 transition-all"
                >
                  <div className="mt-1">
                    <HazardIcon type={event.type} />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-sm leading-tight mb-1">{event.title}</h4>
                    <div className="flex items-center gap-3 text-[10px] text-gray-500">
                      <span className="flex items-center gap-1"><Clock size={10} /> {new Date(event.timestamp).toLocaleTimeString()}</span>
                      <span className="flex items-center gap-1"><MapPin size={10} /> {event.source}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
        </div>

        <div className="space-y-4">
            <h2 className="text-xl font-bold flex items-center gap-2">
                <Navigation size={20} className="text-emerald-500" />
                Nearest Safe Points
            </h2>
            <div className="space-y-3">
                <div className="glass-panel p-4 rounded-2xl border-l-4 border-emerald-600 hover:bg-white/5 cursor-pointer">
                    <div className="flex justify-between items-start mb-1">
                        <h4 className="font-bold text-sm">St. Jude Medical Center</h4>
                        <span className="text-[9px] font-bold text-emerald-500">1.2 KM</span>
                    </div>
                    <p className="text-[10px] text-gray-500">Capacity: 85% Full • ER Status: Critical Only</p>
                </div>
                <div className="glass-panel p-4 rounded-2xl border-l-4 border-emerald-600 hover:bg-white/5 cursor-pointer">
                    <div className="flex justify-between items-start mb-1">
                        <h4 className="font-bold text-sm">Arena Shelter Alpha</h4>
                        <span className="text-[9px] font-bold text-emerald-500">2.4 KM</span>
                    </div>
                    <p className="text-[10px] text-gray-500">Capacity: Limited • Basic Med Supplies available</p>
                </div>
            </div>
        </div>
      </section>

      {/* Offline Guides */}
      <section className="space-y-4 pb-10">
        <h2 className="text-xl font-bold">Offline Resilience Library</h2>
        <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
          {['First Aid Basics', 'Water Purification', 'Emergency Shelters', 'Triage Guide'].map(guide => (
            <div key={guide} className="flex-shrink-0 w-48 h-32 glass-panel p-4 rounded-3xl flex flex-col justify-between hover:border-white/30 cursor-pointer group">
              <div className="w-8 h-8 rounded-lg bg-gray-800 flex items-center justify-center group-hover:bg-red-600/20 group-hover:text-red-500 transition-colors">
                <AlertCircle size={16} />
              </div>
              <span className="font-bold text-sm">{guide}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Dashboard;
