
import React from 'react';
import { ThreatLevel } from '../types';
import { ShieldAlert, Phone } from 'lucide-react';

interface WidgetProps {
  threatLevel: ThreatLevel;
  onSOS: () => void;
}

const AppVaultWidget: React.FC<WidgetProps> = ({ threatLevel, onSOS }) => {
  const getLevelColor = () => {
    switch (threatLevel) {
      case ThreatLevel.CRITICAL: return 'bg-red-600';
      case ThreatLevel.HIGH: return 'bg-orange-500';
      case ThreatLevel.MEDIUM: return 'bg-yellow-500';
      default: return 'bg-emerald-500';
    }
  };

  return (
    <div className="flex items-center gap-2 glass-panel p-1.5 rounded-2xl border border-white/5">
      <div className="flex items-center gap-3 px-3 py-1 bg-white/5 rounded-xl">
        <div className={`w-2.5 h-2.5 rounded-full ${getLevelColor()} animate-pulse shadow-[0_0_8px_rgba(255,255,255,0.3)]`} />
        <div className="flex flex-col">
          <span className="text-[9px] text-gray-400 uppercase font-bold tracking-widest leading-none">Status</span>
          <span className="text-[11px] font-bold leading-none mt-1">{threatLevel}</span>
        </div>
      </div>
      
      <button 
        onClick={onSOS}
        className="flex items-center gap-2 bg-red-600 hover:bg-red-700 px-4 py-2 rounded-xl transition-all shadow-lg shadow-red-900/20 group"
      >
        <Phone size={14} className="group-hover:animate-bounce" />
        <span className="text-[11px] font-extrabold uppercase tracking-wider">SOS</span>
      </button>
    </div>
  );
};

export default AppVaultWidget;
